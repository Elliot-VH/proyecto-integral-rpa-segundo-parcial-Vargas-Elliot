# Evidencia del equipo

Integrantes: 
Sistema / Python / Tesseract / spa disponible: 
Ruta del ensayo: 
LLM real o simulado / modelo (si real): 

## Inspección

PDF digital, caracteres extraídos: 
PDF escaneados, caracteres extraídos directamente: 
Diferencia entre OCR, extracción, validación y revisión: 

## Observaciones por campo

Completa una fila por cada campo de cada documento (15 filas).

| Caso | Campo | Visible en original | Texto OCR | Reglas | LLM y modo | Coincide | Formato válido | Diagnóstico confirmado |
|---|---|---|---|---|---|---|---|---|
| C01 | id_solicitud | | | | | | | |

Diagnósticos: OCR, extracción, incumplimiento de reglas, ausente/incierto, fallo técnico. Pueden coexistir. No confundir una hipótesis automática de OCR con una comprobación visual.

## Ejercicio de modificación

Cambio general de etiqueta Area / Área: 
Prueba agregada y resultado: 
Por qué no memoriza documentos: 

## Comparación y revisión

Huellas OCR iguales por caso: 
Aciertos observados de reglas (por documento): 
Aciertos observados del LLM real, o NO MEDIDO si simulado: 
Limitaciones de la comparación literal de descripciones: 
Método elegido para CSV: 
Filas aprobadas, revisor y justificación: 
Casos pendientes y causa: 

## Evidencias

Rutas de OCR, JSON de ambos métodos, reporte, pendientes, revisión y CSV: 
Resultado de unittest: 

## Reflexión de 150-200 palabras

Escribe aquí.
